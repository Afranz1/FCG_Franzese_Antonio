//GUI SETTINGS
  const settings = {
    D: 13,
    posX: 10,
    posY: 12,
    posZ: 5.5,
    targetX: 0,
    targetY: 1,
    targetZ: 0,
    projWidth: 7,
    projHeight: 7,
    spotLight: false,
    lightFieldOfView: 60,
    bias: -0.006,
    lightFrustum: false,
    dx: 0,
    dz: 0,
    dy: 0,
    shadows: false,
    changeCamera: true,
    firstPerson: false,
    draw: false,
  };


  //TEXTURES
const CORNICE = 0;
const PATH_CORNICE = 'textures/cornice.jpg';
const PARETE = 1;
const PATH_PARETE = 'textures/wall.jpg';
const FLOOR = 2;
const PATH_FLOOR = 'textures/marmo.jpg';
const QUADRO2 = 3;
const PATH_QUADRO2 = 'textures/LoveMe.jpg';
const PENNELLO = 4;
const PATH_PENNELLO = 'textures/pennello.jpg';
const ME = 5;
const PATH_ME= 'textures/me-01.jpg';
const HEART = 6;
const PATH_HEART = 'textures/heart.jpg';
const BARRIER = 7;
const PATH_BARRIER = 'textures/barrier.jpg';
const INGRESSO = 8;
const PATH_INGRESSO = 'textures/ingresso.jpg';
const SPONGE = 9;
const PATH_SPONGE = 'textures/spongebob.jpg';
const FIAMME = 10;
const PATH_FIAMME = 'textures/fiamme.jpg';
const PROUD = 11;
const PATH_PROUD = 'textures/proud.jpg';
const ANTONIO = 12;
const PATH_ANTONIO = 'textures/Antonio.jpg';
const SFAMML = 13;
const PATH_SFAMML = 'textures/sfamml.jpg';
const txt = [];

// CAMERA FIELD OF VIEW
const fieldOfViewRadians = degToRad(60);






