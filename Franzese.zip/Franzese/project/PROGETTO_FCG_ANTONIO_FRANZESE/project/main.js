'use strict';

var angle = 0;
var spacebar = false;
async function main() {
  
  /** @type {HTMLCanvasElement} */
  const canvas = document.getElementById('canvas');
  const gl = canvas.getContext('webgl');
  if (!gl) {
    return;
  }

  const ext = gl.getExtension('WEBGL_depth_texture');
  if (!ext) {
    return alert('need WEBGL_depth_texture');
  }

  define_gui();

  const sceneProgramInfo = webglUtils.createProgramInfo(gl, ['vertex-shader-3d', 'fragment-shader-3d']);
  const colorProgramInfo = webglUtils.createProgramInfo(gl, ['color-vertex-shader', 'color-fragment-shader']);

  txt[0] = textureFromImage(gl, PATH_CORNICE);
  txt[1] = textureFromImage(gl, PATH_PARETE);
  txt[2] = textureFromImage(gl, PATH_FLOOR);
  txt[3] = textureFromImage(gl, PATH_QUADRO2);
  txt[4] = textureFromImage(gl, PATH_PENNELLO);
  txt[5] = textureFromImage(gl, PATH_ME);
  txt[6] = textureFromImage(gl, PATH_HEART);
  txt[7] = textureFromImage(gl, PATH_BARRIER);
  txt[8] = textureFromImage(gl, PATH_INGRESSO);
  txt[9] = textureFromImage(gl, PATH_SPONGE);
  txt[10] = textureFromImage(gl, PATH_FIAMME);
  txt[11] = textureFromImage(gl, PATH_PROUD);
  txt[12] = textureFromImage(gl, PATH_ANTONIO);
  txt[13] = textureFromImage(gl, PATH_SFAMML);



  const planeBufferInfo = primitives.createPlaneBufferInfo(
    gl,
    20,  
    20,  
    2, 
    2,
);

const cubeLinesBufferInfo = webglUtils.createBufferInfoFromArrays(gl, {
  position: [
    -1, -1, -1,
     1, -1, -1,
    -1,  1, -1,
     1,  1, -1,
    -1, -1,  1,
     1, -1,  1,
    -1,  1,  1,
     1,  1,  1,
  ],
  indices: [
    0, 1,
    1, 3,
    3, 2,
    2, 0,

    4, 5,
    5, 7,
    7, 6,
    6, 4,

    0, 4,
    1, 5,
    3, 7,
    2, 6,
  ],
});


//LOAD OBJ 

 // PENNELLO 

 const objHref = 'data/pennello.obj';  
 const response = await fetch(objHref);
 const text = await response.text();
 const obj = parseOBJ(text);
 const baseHref = new URL(objHref, window.location.href);
 const matTexts = await Promise.all(obj.materialLibs.map(async filename => {
   const matHref = new URL(filename, baseHref).href;
   const response = await fetch(matHref);
   return await response.text();
 }));
 const materials = parseMTL(matTexts.join('\n'));

 const textures = {
   defaultWhite: create1PixelTexture(gl, [255, 255, 255, 255]),
 };

 for (const material of Object.values(materials)) {
   Object.entries(material)
     .filter(([key]) => key.endsWith('Map'))
     .forEach(([key, filename]) => {
       let texture = textures[filename];
       if (!texture) {
         const textureHref = new URL(filename, baseHref).href;
         texture = createTexture(gl, textureHref);
         textures[filename] = texture;
       }
       material[key] = texture;
     });
 }

 const defaultMaterial = {
   diffuse: [1, 1, 1],
   diffuseMap: textures.defaultWhite,
   ambient: [0, 0, 0],
   specular: [1, 1, 1],
   shininess: 400,
   opacity: 1,
 };

 const parts = obj.geometries.map(({material, data}) => {
   if (data.color) {
     if (data.position.length === data.color.length) {
       data.color = { numComponents: 3, data: data.color };
     }
   } else {
     data.color = { value: [1, 1, 1, 1] };
   }
   const bufferInfo = webglUtils.createBufferInfoFromArrays(gl, data);
   return {
     material: {
       ...defaultMaterial,
       ...materials[material],
     },
     bufferInfo,
   };
 });
 
 

 // QUADRO 

 const objHref_quadro = 'data/quadro2.obj';  
 const response_quadro = await fetch(objHref_quadro);
 const text_quadro = await response_quadro.text();
 const obj_quadro = parseOBJ(text_quadro);
 const baseHref_quadro = new URL(objHref_quadro, window.location.href);
 const matTexts_quadro = await Promise.all(obj.materialLibs.map(async filename => {
   const matHref_quadro = new URL(filename, baseHref_quadro).href;
   const response_quadro = await fetch(matHref_quadro);
   return await response_quadro.text();
 }));

 const materials_quadro = parseMTL(matTexts_quadro.join('\n'));

 const parts_quadro = obj_quadro.geometries.map(({material, data}) => {
   

   if (data.color) {
     if (data.position.length === data.color.length) {
       data.color = { numComponents: 3, data: data.color };
     }
   } else {
     data.color = { value: [1, 1, 1, 1] };
   }
   const bufferInfo = webglUtils.createBufferInfoFromArrays(gl, data);
   return {
     material: {
       ...defaultMaterial,
       ...materials_quadro[material],
     },
     bufferInfo,
   };
 });

 // QUADRO 2
 const objHref_quadro2 = 'data/LoveMe.obj';  
 const response_quadro2 = await fetch(objHref_quadro2);
 const text_quadro2 = await response_quadro2.text();
 const obj_quadro2 = parseOBJ(text_quadro2);
 const baseHref_quadro2 = new URL(objHref_quadro2, window.location.href);
 const matTexts_quadro2 = await Promise.all(obj.materialLibs.map(async filename => {
   const matHref_quadro2 = new URL(filename, baseHref_quadro2).href;
   const response_quadro2 = await fetch(matHref_quadro2);
   return await response_quadro2.text();
 }));

 const materials_quadro2 = parseMTL(matTexts_quadro2.join('\n'));

 const parts_quadro2 = obj_quadro2.geometries.map(({material, data}) => {
   

   if (data.color) {
     if (data.position.length === data.color.length) {
       data.color = { numComponents: 3, data: data.color };
     }
   } else {
     data.color = { value: [1, 1, 1, 1] };
   }
   const bufferInfo = webglUtils.createBufferInfoFromArrays(gl, data);
   return {
     material: {
       ...defaultMaterial,
       ...materials_quadro2[material],
     },
     bufferInfo,
   };
 });

  // QUADRO 3
  const objHref_quadro3 = 'data/quadro3.obj';  
  const response_quadro3 = await fetch(objHref_quadro3);
  const text_quadro3 = await response_quadro3.text();
  const obj_quadro3 = parseOBJ(text_quadro3);
  const baseHref_quadro3 = new URL(objHref_quadro3, window.location.href);
  const matTexts_quadro3 = await Promise.all(obj.materialLibs.map(async filename => {
    const matHref_quadro3 = new URL(filename, baseHref_quadro3).href;
    const response_quadro3 = await fetch(matHref_quadro3);
    return await response_quadro3.text();
  }));
 
  const materials_quadro3 = parseMTL(matTexts_quadro3.join('\n'));
 
  const parts_quadro3 = obj_quadro3.geometries.map(({material, data}) => {
    
 
    if (data.color) {
      if (data.position.length === data.color.length) {
        data.color = { numComponents: 3, data: data.color };
      }
    } else {
      data.color = { value: [1, 1, 1, 1] };
    }
    const bufferInfo = webglUtils.createBufferInfoFromArrays(gl, data);
    return {
      material: {
        ...defaultMaterial,
        ...materials_quadro3[material],
      },
      bufferInfo,
    };
  });

    // QUADRO 4
    const objHref_quadro4 = 'data/spongebob.obj';  
    const response_quadro4 = await fetch(objHref_quadro4);
    const text_quadro4 = await response_quadro4.text();
    const obj_quadro4 = parseOBJ(text_quadro4);
    const baseHref_quadro4 = new URL(objHref_quadro4, window.location.href);
    const matTexts_quadro4 = await Promise.all(obj.materialLibs.map(async filename => {
      const matHref_quadro4 = new URL(filename, baseHref_quadro4).href;
      const response_quadro4 = await fetch(matHref_quadro4);
      return await response_quadro4.text();
    }));
   
    const materials_quadro4 = parseMTL(matTexts_quadro4.join('\n'));
   
    const parts_quadro4 = obj_quadro4.geometries.map(({material, data}) => {
      
   
      if (data.color) {
        if (data.position.length === data.color.length) {
          data.color = { numComponents: 3, data: data.color };
        }
      } else {
        data.color = { value: [1, 1, 1, 1] };
      }
      const bufferInfo = webglUtils.createBufferInfoFromArrays(gl, data);
      return {
        material: {
          ...defaultMaterial,
          ...materials_quadro4[material],
        },
        bufferInfo,
      };
    });

      // QUADRO 5
      const objHref_quadro5 = 'data/fiamme.obj';  
      const response_quadro5 = await fetch(objHref_quadro5);
      const text_quadro5 = await response_quadro5.text();
      const obj_quadro5 = parseOBJ(text_quadro5);
      const baseHref_quadro5 = new URL(objHref_quadro5, window.location.href);
      const matTexts_quadro5 = await Promise.all(obj.materialLibs.map(async filename => {
        const matHref_quadro5 = new URL(filename, baseHref_quadro5).href;
        const response_quadro5 = await fetch(matHref_quadro5);
        return await response_quadro5.text();
      }));
     
      const materials_quadro5 = parseMTL(matTexts_quadro5.join('\n'));
     
      const parts_quadro5 = obj_quadro5.geometries.map(({material, data}) => {
        
     
        if (data.color) {
          if (data.position.length === data.color.length) {
            data.color = { numComponents: 3, data: data.color };
          }
        } else {
          data.color = { value: [1, 1, 1, 1] };
        }
        const bufferInfo = webglUtils.createBufferInfoFromArrays(gl, data);
        return {
          material: {
            ...defaultMaterial,
            ...materials_quadro5[material],
          },
          bufferInfo,
        };
      });

       // QUADRO 6
       const objHref_quadro6 = 'data/proud.obj';  
       const response_quadro6 = await fetch(objHref_quadro6);
       const text_quadro6 = await response_quadro6.text();
       const obj_quadro6 = parseOBJ(text_quadro6);
       const baseHref_quadro6 = new URL(objHref_quadro6, window.location.href);
       const matTexts_quadro6 = await Promise.all(obj.materialLibs.map(async filename => {
         const matHref_quadro6 = new URL(filename, baseHref_quadro6).href;
         const response_quadro6 = await fetch(matHref_quadro6);
         return await response_quadro6.text();
       }));
      
       const materials_quadro6 = parseMTL(matTexts_quadro6.join('\n'));
      
       const parts_quadro6 = obj_quadro6.geometries.map(({material, data}) => {
         
      
         if (data.color) {
           if (data.position.length === data.color.length) {
             data.color = { numComponents: 3, data: data.color };
           }
         } else {
           data.color = { value: [1, 1, 1, 1] };
         }
         const bufferInfo = webglUtils.createBufferInfoFromArrays(gl, data);
         return {
           material: {
             ...defaultMaterial,
             ...materials_quadro6[material],
           },
           bufferInfo,
         };
       });

              // QUADRO 7
       const objHref_quadro7 = 'data/Antonio.obj';  
       const response_quadro7 = await fetch(objHref_quadro7);
       const text_quadro7 = await response_quadro7.text();
       const obj_quadro7 = parseOBJ(text_quadro7);
       const baseHref_quadro7 = new URL(objHref_quadro7, window.location.href);
       const matTexts_quadro7= await Promise.all(obj.materialLibs.map(async filename => {
         const matHref_quadro7 = new URL(filename, baseHref_quadro7).href;
         const response_quadro7 = await fetch(matHref_quadro7);
         return await response_quadro7.text();
       }));
      
       const materials_quadro7 = parseMTL(matTexts_quadro7.join('\n'));
      
       const parts_quadro7 = obj_quadro7.geometries.map(({material, data}) => {
         
      
         if (data.color) {
           if (data.position.length === data.color.length) {
             data.color = { numComponents: 3, data: data.color };
           }
         } else {
           data.color = { value: [1, 1, 1, 1] };
         }
         const bufferInfo = webglUtils.createBufferInfoFromArrays(gl, data);
         return {
           material: {
             ...defaultMaterial,
             ...materials_quadro7[material],
           },
           bufferInfo,
         };
       });

        // QUADRO 8
       const objHref_quadro8 = 'data/sfamml.obj';  
       const response_quadro8 = await fetch(objHref_quadro8);
       const text_quadro8 = await response_quadro8.text();
       const obj_quadro8 = parseOBJ(text_quadro8);
       const baseHref_quadro8 = new URL(objHref_quadro8, window.location.href);
       const matTexts_quadro8= await Promise.all(obj.materialLibs.map(async filename => {
         const matHref_quadro8 = new URL(filename, baseHref_quadro8).href;
         const response_quadro8 = await fetch(matHref_quadro8);
         return await response_quadro8.text();
       }));
      
       const materials_quadro8 = parseMTL(matTexts_quadro8.join('\n'));
      
       const parts_quadro8 = obj_quadro8.geometries.map(({material, data}) => {
         
      
         if (data.color) {
           if (data.position.length === data.color.length) {
             data.color = { numComponents: 3, data: data.color };
           }
         } else {
           data.color = { value: [1, 1, 1, 1] };
         }
         const bufferInfo = webglUtils.createBufferInfoFromArrays(gl, data);
         return {
           material: {
             ...defaultMaterial,
             ...materials_quadro8[material],
           },
           bufferInfo,
         };
       });


    // BARRIER
    const objHref_barrier = 'data/barrier.obj';  
    const response_barrier = await fetch(objHref_barrier);
    const text_barrier = await response_barrier.text();
    const obj_barrier = parseOBJ(text_barrier);
    const baseHref_barrier = new URL(objHref_barrier, window.location.href);
    const matTexts_barrier = await Promise.all(obj.materialLibs.map(async filename => {
      const matHref_barrier = new URL(filename, baseHref_barrier).href;
      const response_barrier = await fetch(matHref_barrier);
      return await response_barrier.text();
    }));
   
    const materials_barrier = parseMTL(matTexts_barrier.join('\n'));
   
    const parts_barrier = obj_barrier.geometries.map(({material, data}) => {
      
   
      if (data.color) {
        if (data.position.length === data.color.length) {
          data.color = { numComponents: 3, data: data.color };
        }
      } else {
        data.color = { value: [1, 1, 1, 1] };
      }
      const bufferInfo = webglUtils.createBufferInfoFromArrays(gl, data);
      return {
        material: {
          ...defaultMaterial,
          ...materials_barrier[material],
        },
        bufferInfo,
      };
    });







//-----UNIFORMS-----//

const ceilingUniforms = {
  u_world:m4.xRotate(m4.translation(0, 15, 0),-3.14159),
  u_texture: txt[PARETE],
};

const floorUniforms = {
  u_colorMult: [1, 1, 1, 1],
  u_color: [1, 1, 1, 1],
  u_texture: txt[FLOOR],
  u_world: m4.translation(0, -5, 0),
};

const wallUniforms1 = {
  u_colorMul: [1, 1, 1, 1],  
  u_color: [1, 1, 1, 1],
  u_texture: txt[PARETE],
  u_world:m4.yRotate(m4.xRotate(m4.translation(0, 5, -10),degToRad(90)),degToRad(360)), 
};

const wallUniforms2 = {
  u_colorMult: [1, 1, 1, 1],  
  u_color: [1, 1, 1, 1],
  u_texture: txt[INGRESSO],
  u_world: m4.yRotate(m4.zRotate(m4.translation(10, 5, 0),degToRad(90)),degToRad(270)), 
};

const wallUniforms3 = {
  u_colorMult: [1, 1, 1, 1],
  u_color: [1, 1, 1, 1],
  u_texture: txt[PARETE],
  u_world:m4.yRotate(m4.xRotate(m4.translation(0, 5, 10),degToRad(270)),degToRad(180)), 
};

const wallUniforms4 = {
  u_colorMult: [1, 1, 1, 1],
  u_color: [1, 1, 1, 1],
  u_texture: txt[PARETE],
  u_world:m4.zRotate(m4.xRotate(m4.translation(-10, 5, 0),degToRad(90)),degToRad(270)),
};

var pennelloUniforms = {
  u_world: m4.yRotate(m4.translation(0, 0, 0),degToRad(180)),
};

var quadroUniforms = {
  u_world: m4.xRotate(m4.yRotate(m4.translation(-8.7, 10, -5),degToRad(0)),degToRad(180)),
  diffuseMap: txt[CORNICE],
};

const quadro2Uniforms = {
  u_world: m4.xRotate(m4.yRotate(m4.translation(-8.2, 10, 5),degToRad(180)),degToRad(360)),
  diffuseMap: txt[QUADRO2],
};

const quadro3Uniforms = {
  u_world: m4.xRotate(m4.yRotate(m4.translation(-6, 8, 8.7),degToRad(90)),degToRad(180)),
  diffuseMap: txt[HEART],
};

const quadro4Uniforms = {
  u_world: m4.xRotate(m4.yRotate(m4.translation(2, 8, 8.2),degToRad(270)),degToRad(180)),
  diffuseMap: txt[SPONGE],
};

const quadro5Uniforms = {
  u_world: m4.xRotate(m4.yRotate(m4.translation(7, 8, 8.2),degToRad(270)),degToRad(180)),
  diffuseMap: txt[FIAMME],
};

const quadro6Uniforms = {
  u_world: m4.xRotate(m4.yRotate(m4.translation(7, 8, -6.7),degToRad(270)),degToRad(180)),
  diffuseMap: txt[PROUD],
};

const quadro7Uniforms = {
  u_world: m4.xRotate(m4.yRotate(m4.translation(-2, 8, -5.1),degToRad(270)),degToRad(180)),
  diffuseMap: txt[ANTONIO],
};

const quadro8Uniforms = {
  u_world: m4.xRotate(m4.yRotate(m4.translation(-7.2, 2, 0),degToRad(180)),degToRad(360)),
  diffuseMap: txt[SFAMML],
};


const barrierUniforms = {
  u_world: m4.xRotate(m4.yRotate(m4.zRotate(m4.translation(-13.3, -2.1, 10.2),degToRad(90)),degToRad(90)),degToRad(90)),
  diffuseMap: txt[BARRIER],
};






//----SHADOWS SETTING----//

const depthTexture = gl.createTexture();
  const depthTextureSize = 512;
  gl.bindTexture(gl.TEXTURE_2D, depthTexture);
  gl.texImage2D(
      gl.TEXTURE_2D,      
      0,                  
      gl.DEPTH_COMPONENT, 
      depthTextureSize,   
      depthTextureSize,   
      0,                  
      gl.DEPTH_COMPONENT, 
      gl.UNSIGNED_INT,    
      null);              
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

  const depthFramebuffer = gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER, depthFramebuffer);
  gl.framebufferTexture2D(
      gl.FRAMEBUFFER,       
      gl.DEPTH_ATTACHMENT, 
      gl.TEXTURE_2D,        
      depthTexture,         
      0);                   

  const unusedTexture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, unusedTexture);
  gl.texImage2D(
      gl.TEXTURE_2D,
      0,
      gl.RGBA,
      depthTextureSize,
      depthTextureSize,
      0,
      gl.RGBA,
      gl.UNSIGNED_BYTE,
      null,
  );
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);


  gl.framebufferTexture2D(
      gl.FRAMEBUFFER,        
      gl.COLOR_ATTACHMENT0,  
      gl.TEXTURE_2D,         
      unusedTexture,        
      0);   


  

  
  //----GUI----//

  function define_gui() {
    var gui = new dat.GUI();
    
    gui.add(settings,"D").min(7).max(22).step(0.1).onChange(function() {
      render();});
    gui.add(settings,"dx").min(-8).max(8).step(1).onChange(function(){
      render();});
    gui.add(settings,"dz").min(-8).max(8).step(1).onChange(function(){
      render();});
    gui.add(settings,"dy").min(-3).max(11).step(0.5).onChange(function(){
      render();});
    gui.add(settings,"posX").min(0).max(20).step(0.5).onChange(function() {
      render();});
    gui.add(settings,"posY").min(0).max(20).step(0.5).onChange(function() {
      render();});
    gui.add(settings,"posZ").min(0).max(20).step(0.5).onChange(function() {
      render();});
    gui.add(settings,"targetX").min(-15).max(15).step(0.5).onChange(function() {
      render();});
    gui.add(settings,"targetY").min(-15).max(15).step(0.5).onChange(function() {
      render();});
    gui.add(settings,"targetZ").min(-15).max(15).step(0.5).onChange(function() {
      render();});
    gui.add(settings,"projWidth").min(0).max(15).step(0.5).onChange(function() {
      render();});
    gui.add(settings,"projHeight").min(0).max(15).step(0.5).onChange(function() {
      render();});
    gui.add(settings,"bias").min(-0.01).max(0.001).step(0.0001).onChange(function() {
      render();});
    gui.add(settings,"lightFieldOfView").min(60).max(120).step(5).onChange(function() {
      render();});
    gui.add(settings,"spotLight").onChange(function() {
      render();});
    gui.add(settings,"lightFrustum").onChange(function() {
      render();});
    gui.add(settings,"shadows").onChange(function() {
      render();});
    gui.add(settings,"changeCamera").onChange(function(){
      render();});
    gui.add(settings,"firstPerson").onChange(function(){
      render();});
    gui.add(settings,"draw").onChange(function(){
      render();});

    gui.close();
}   


//----DRAW----//

function drawScene(projectionMatrix,cameraMatrix,textureMatrix,lightWorldMatrix,programInfo) {

  const viewMatrix = m4.inverse(cameraMatrix);
  gl.useProgram(programInfo.program);

  webglUtils.setUniforms(programInfo, {
    u_view: viewMatrix,
    u_projection: projectionMatrix,
    u_bias: settings.bias,
    u_textureMatrix: textureMatrix,
    u_projectedTexture: depthTexture,
    u_reverseLightDirection: lightWorldMatrix.slice(8, 11),
  });
  

  gl.uniform1f(gl.getUniformLocation(programInfo.program, "mesh"), 0.);

  // ------ Draw the ceiling -----
  webglUtils.setBuffersAndAttributes(gl, programInfo, planeBufferInfo);
  webglUtils.setUniforms(programInfo, ceilingUniforms);
  webglUtils.drawBufferInfo(gl, planeBufferInfo);


  // ------ Draw the floor --------
  webglUtils.setBuffersAndAttributes(gl, programInfo, planeBufferInfo);
  webglUtils.setUniforms(programInfo, floorUniforms);
 
  webglUtils.drawBufferInfo(gl, planeBufferInfo);

   // ------ Draw the first wall --------
   webglUtils.setBuffersAndAttributes(gl, programInfo, planeBufferInfo);
   webglUtils.setUniforms(programInfo, wallUniforms1);
   webglUtils.drawBufferInfo(gl, planeBufferInfo);


   // ------ Draw the second wall --------
   webglUtils.setBuffersAndAttributes(gl, programInfo, planeBufferInfo);
   webglUtils.setUniforms(programInfo, wallUniforms2);
   webglUtils.drawBufferInfo(gl, planeBufferInfo);


    // ------ Draw the third wall --------
   webglUtils.setBuffersAndAttributes(gl, programInfo, planeBufferInfo);
   webglUtils.setUniforms(programInfo, wallUniforms3);
   webglUtils.drawBufferInfo(gl, planeBufferInfo);

   // ------ Draw the fourth wall --------
   webglUtils.setBuffersAndAttributes(gl, programInfo, planeBufferInfo);
   webglUtils.setUniforms(programInfo, wallUniforms4);
   webglUtils.drawBufferInfo(gl, planeBufferInfo);



   // ---- Draw OBJS -----
   gl.uniform1f(gl.getUniformLocation(programInfo.program, "mesh"), 1.);

   // ---- Draw Pennello ----
   webglUtils.setUniforms(programInfo, pennelloUniforms);
   for (const {bufferInfo, material} of parts) {
     webglUtils.setBuffersAndAttributes(gl, programInfo, bufferInfo);
     webglUtils.setUniforms(programInfo, material);
     webglUtils.drawBufferInfo(gl, bufferInfo);
   }


    // ----- Draw QUADRO ----
    webglUtils.setUniforms(programInfo, quadroUniforms);
    for (const {bufferInfo, material} of parts_quadro) {
      webglUtils.setBuffersAndAttributes(gl, programInfo, bufferInfo);
      webglUtils.setUniforms(programInfo, materials_quadro);
      webglUtils.drawBufferInfo(gl, bufferInfo);
    }

      // ----- Draw LoveME ----
      webglUtils.setUniforms(programInfo, quadro2Uniforms);
      for (const {bufferInfo, material} of parts_quadro2) {
        webglUtils.setBuffersAndAttributes(gl, programInfo, bufferInfo);
        webglUtils.setUniforms(programInfo, materials_quadro2);
        webglUtils.drawBufferInfo(gl, bufferInfo);
      }

        // ----- Draw HEART ----
        webglUtils.setUniforms(programInfo, quadro3Uniforms);
        for (const {bufferInfo, material} of parts_quadro3) {
          webglUtils.setBuffersAndAttributes(gl, programInfo, bufferInfo);
          webglUtils.setUniforms(programInfo, materials_quadro3);
          webglUtils.drawBufferInfo(gl, bufferInfo);
        }
         // ----- Draw SPONGE ----
       webglUtils.setUniforms(programInfo, quadro4Uniforms);
        for (const {bufferInfo, material} of parts_quadro4) {
         webglUtils.setBuffersAndAttributes(gl, programInfo, bufferInfo);
         webglUtils.setUniforms(programInfo, materials_quadro4);
         webglUtils.drawBufferInfo(gl, bufferInfo);
         }
            // ----- Draw FIAMME ----
       webglUtils.setUniforms(programInfo, quadro5Uniforms);
       for (const {bufferInfo, material} of parts_quadro5) {
        webglUtils.setBuffersAndAttributes(gl, programInfo, bufferInfo);
        webglUtils.setUniforms(programInfo, materials_quadro5);
        webglUtils.drawBufferInfo(gl, bufferInfo);
        }
             // ----- Draw PROUD ----
       webglUtils.setUniforms(programInfo, quadro6Uniforms);
       for (const {bufferInfo, material} of parts_quadro6) {
        webglUtils.setBuffersAndAttributes(gl, programInfo, bufferInfo);
        webglUtils.setUniforms(programInfo, materials_quadro6);
        webglUtils.drawBufferInfo(gl, bufferInfo);
        }
               // ----- Draw ANTONIO ----
       webglUtils.setUniforms(programInfo, quadro7Uniforms);
       for (const {bufferInfo, material} of parts_quadro7) {
        webglUtils.setBuffersAndAttributes(gl, programInfo, bufferInfo);
        webglUtils.setUniforms(programInfo, materials_quadro6);
        webglUtils.drawBufferInfo(gl, bufferInfo);
        }
                 // ----- Draw SFAMML ----
       webglUtils.setUniforms(programInfo, quadro8Uniforms);
       for (const {bufferInfo, material} of parts_quadro8) {
        webglUtils.setBuffersAndAttributes(gl, programInfo, bufferInfo);
        webglUtils.setUniforms(programInfo, materials_quadro6);
        webglUtils.drawBufferInfo(gl, bufferInfo);
        }

        // ----- Draw BARRIER ----
        webglUtils.setUniforms(programInfo, barrierUniforms);
        for (const {bufferInfo, material} of parts_barrier) {
          webglUtils.setBuffersAndAttributes(gl, programInfo, bufferInfo);
          webglUtils.setUniforms(programInfo, materials_barrier);
          webglUtils.drawBufferInfo(gl, bufferInfo);
        }


     
 









}


//---MOUSE EVENT---//

var THETA = degToRad(90), PHI = degToRad(75);
var drag, old_x, old_y, dX, dY;

canvas.addEventListener("wheel", function(e){
  if(settings.D + e.deltaY/100 > 6){
  settings.D += e.deltaY/100;
  render();
  }
 });


  canvas.addEventListener("mousedown", function(e) {
      drag = true;
      old_x = e.pageX
      old_y = e.pageY;
      e.preventDefault();
  }, false)

  canvas.addEventListener("mouseup", function(e) {
      drag = false;
  }, false)

  canvas.addEventListener("mousemove", function(e) {
      if (!drag) {
          return false; 
      }
      dX = -(e.pageX - old_x) * 2 * Math.PI / canvas.width; 
      dY = -(e.pageY - old_y) * 2 * Math.PI / canvas.height; 
      THETA += dX;
      PHI += dY;
      old_x = e.pageX;
      old_y = e.pageY; 
      e.preventDefault();
      render();
  }, false);


    
canvas.addEventListener("touchstart", function (e) {
    drag = true;
    old_x =  e.touches[0].clientX;
    old_y =  e.touches[0].clientY;
    e.preventDefault();  
}, false);

canvas.addEventListener("touchend", function (e) {
    drag = false;
}, false);

canvas.addEventListener("touchmove", function (e) {
    if (!drag) {
        return false; 
    }
    dX = -(e.touches[0].clientX - old_x) * 2 * Math.PI / canvas.width; 
    dY = -(e.touches[0].clientY - old_y) * 2 * Math.PI / canvas.height; 
    THETA += dX;
    PHI += dY;
    old_x = e.touches[0].clientX;
    old_y = e.touches[0].clientY;
    e.preventDefault();
    render();
}, false);



//---KEY EVENT---//

window.addEventListener("keydown", function (event) {
    
  if (event.defaultPrevented) {
      return;
  }
  let DeltaX = Math.cos(angle),DeltaZ = Math.sin(angle);
  switch (event.key) {
      case "s": 
        if((settings.dx+DeltaX)<=8 && (settings.dx+DeltaX) >=-8 && (settings.dz-DeltaZ)<=8 && (settings.dz-DeltaZ) >=-8){
          settings.dx += DeltaX;
          settings.dz -= DeltaZ;
          render();
          }
          break;
      case "d": 
          angle -= degToRad(3);
          if(settings.changeCamera){
            THETA -= degToRad(3);
          }
          render();
          break;
      case "w":
        if((settings.dx-DeltaX) <=8 && (settings.dx-DeltaX) >=-8 && (settings.dz+DeltaZ)<=8 && (settings.dz+DeltaZ) >=-8){
          settings.dx-= DeltaX;
          settings.dz+= DeltaZ;
          render();
          }
          break;
      case "a": 
            angle += degToRad(3);
            if(settings.changeCamera){
              THETA += degToRad(3);
            }
            render();
          break;
      case "ArrowUp": 
        if(settings.dy<=10){
            settings.dy += 1;
            render();
          }
          break;
      case " ":

        if(settings.dx >= -10 && settings.dx <= -6 && settings.dy >= 8 && settings.dy <= 11 && settings.dz >= -5 && settings.dz <= -2 ){
        spacebar= true;
        render();
        }
        break;
      case "ArrowDown": 
        if(settings.dy>=-2){
            settings.dy -= 1;
            render();
          }
          break;
      default:
          console.log(event.key);
  }
  event.preventDefault(); 
}, true);




//---RENDER---//




function render() {
  webglUtils.resizeCanvasToDisplaySize(gl.canvas);

  gl.enable(gl.CULL_FACE);
  gl.enable(gl.DEPTH_TEST);

  const lightWorldMatrix = m4.lookAt(
      [settings.posX, settings.posY, settings.posZ],         
      [settings.targetX, settings.targetY, settings.targetZ], 
      [0, 1, 0],                                             
  );
  const lightProjectionMatrix = settings.spotLight
      ? m4.perspective(
          degToRad(settings.lightFieldOfView),
          settings.projWidth / settings.projHeight,
          1,  
          28)   
      : m4.orthographic(
          -settings.projWidth / 2,   
           settings.projWidth / 2,   
          -settings.projHeight / 2, 
           settings.projHeight / 2,  
           1,                      
           28);    
                  

  gl.bindFramebuffer(gl.FRAMEBUFFER, depthFramebuffer);
  gl.viewport(0, 0, depthTextureSize, depthTextureSize);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

  var target = [0, 0, 0];
  const up = [0, 10, 0];


  //----FIRST PERSON----//
  if(settings.firstPerson){
    settings.D = 0.8;
  }

  
  
  //----CHANGE CAMERA----//
  var targetPencil = [settings.dx, settings.dy, settings.dz];
  var cameraPencil = [settings.dx+settings.D*Math.sin(THETA)*Math.sin(PHI), settings.dy + settings.D*Math.cos(PHI), settings.dz+settings.D*Math.cos(THETA)*Math.sin(PHI)];
  
  var camera = [settings.D*Math.sin(THETA)*Math.sin(PHI), settings.D*Math.cos(PHI), settings.D*Math.cos(THETA)*Math.sin(PHI)];
  if(settings.changeCamera){
    camera = cameraPencil;
    target=targetPencil;
  }
  

  const cameraMatrix = m4.lookAt(camera, target, up) ;
  pennelloUniforms = {
    u_world: m4.yRotate(m4.translation(settings.dx, settings.dy, settings.dz),angle),
  };
  
  if(settings.shadows){
    drawScene(lightProjectionMatrix,lightWorldMatrix,m4.identity(),lightWorldMatrix,colorProgramInfo);
  }
  if(settings.dx >= -10 && settings.dx <= -6 && settings.dy >= 8 && settings.dy <= 11 && settings.dz >= -5 && settings.dz <= -2 && settings.draw){
    spacebar= true;
    }
  if(spacebar){
  quadroUniforms = {
    u_world: m4.xRotate(m4.yRotate(m4.translation(-8.7, 10, -5),degToRad(0)),degToRad(180)),
    diffuseMap: txt[ME],

  }
}
  
  
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
  gl.clearColor(0, 0, 0, 1);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

  let textureMatrix = m4.identity();
  textureMatrix = m4.translate(textureMatrix, 0.5, 0.5, 0.5);
  textureMatrix = m4.scale(textureMatrix, 0.5, 0.5, 0.5);
  textureMatrix = m4.multiply(textureMatrix, lightProjectionMatrix);
  
  textureMatrix = m4.multiply(
      textureMatrix,
      m4.inverse(lightWorldMatrix));

 
  const aspect = gl.canvas.clientWidth / gl.canvas.clientHeight;
  const projectionMatrix =
      m4.perspective(fieldOfViewRadians, aspect, 1, 2000); 

  const viewMatrix = m4.inverse(cameraMatrix);
  const viewProjectionMatrix = m4.multiply(projectionMatrix, viewMatrix);
  
  drawScene(viewProjectionMatrix,cameraMatrix,textureMatrix,lightWorldMatrix,sceneProgramInfo);
    
  if(settings.lightFrustum){
    const viewMatrix = m4.inverse(cameraMatrix);
    gl.useProgram(colorProgramInfo.program);

  
    webglUtils.setBuffersAndAttributes(gl, colorProgramInfo, cubeLinesBufferInfo);

    const mat = m4.multiply(
        lightWorldMatrix, m4.inverse(lightProjectionMatrix));
    webglUtils.setUniforms(colorProgramInfo, {
      u_color: [1, 1, 1, 1],
      u_view: viewMatrix,
      u_projection: projectionMatrix,
      u_world: mat,
    });
    webglUtils.drawBufferInfo(gl, cubeLinesBufferInfo, gl.LINES);
  }
  
}
render();
}